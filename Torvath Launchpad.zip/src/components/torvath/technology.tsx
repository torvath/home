const STACK = [
  "TypeScript",
  "React",
  "Node",
  "Python",
  "PostgreSQL",
  "AWS",
];

export function Technology() {
  return (
    <section className="border-b border-hairline bg-surface">
      <div className="mx-auto max-w-7xl px-5 py-16 sm:px-8">
        <p className="label-caps text-center">Technology we work in</p>
        <ul className="mt-8 flex flex-wrap items-center justify-center">
          {STACK.map((tech, i) => (
            <li key={tech} className="flex items-center">
              {i > 0 && (
                <span aria-hidden className="mx-4 h-4 w-px bg-hairline sm:mx-6" />
              )}
              <span className="font-display text-[0.7rem] tracking-[0.26em] text-foreground/80 uppercase sm:text-xs">
                {tech}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
