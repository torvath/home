import { ArrowRight, X } from "lucide-react";
import { type ServiceTitle } from "./services";

const SERVICE_DETAILS: Record<
  ServiceTitle,
  {
    accent: "teal" | "amber";
    intro: string;
    points: string[];
  }
> = {
  "Software development": {
    accent: "teal",
    intro:
      "We design and build software that becomes the operating system of your business — from customer-facing products to internal tools that move faster than spreadsheets.",
    points: [
      "Custom web applications tailored to your workflow",
      "API design and third-party integrations",
      "Frontend and backend engineering with modern stacks",
      "Cloud deployment, CI/CD, and infrastructure setup",
      "Mobile-ready experiences and responsive interfaces",
    ],
  },
  Consulting: {
    accent: "teal",
    intro:
      "When a project is stuck, over-engineered, or unclear, we step in to find the shortest path forward — and leave your team with a plan they can execute.",
    points: [
      "Architecture and code-base reviews",
      "Technology selection and migration roadmaps",
      "Team augmentation and hiring support",
      "Project recovery and deadline rescue",
      "Proof-of-concept builds for uncertain bets",
    ],
  },
  Products: {
    accent: "amber",
    intro:
      "Beyond client work, we build and operate products we believe in — starting with our own platforms and exploring new tools that solve problems we see firsthand.",
    points: [
      "In-house SaaS products built and operated by Torvath",
      "Torvath Rentals — a rental management platform",
      "Continuous iteration based on real user feedback",
      "New product concepts in development",
      "Opportunities to partner or co-build with us",
    ],
  },
  "Managed services": {
    accent: "amber",
    intro:
      "Shipping is the beginning, not the end. We stay with the software we build to keep it secure, fast, and evolving as your business changes.",
    points: [
      "Ongoing maintenance and reliability work",
      "Monitoring, alerting, and incident response",
      "Feature updates and incremental improvements",
      "Security patches and dependency management",
      "Quarterly planning and performance reviews",
    ],
  },
};

export const SERVICE_TITLES = Object.keys(
  SERVICE_DETAILS,
) as ServiceTitle[];

interface ServiceDetailProps {
  active: ServiceTitle | null;
  onSelect: (key: ServiceTitle | null) => void;
}

export function ServiceDetail({ active, onSelect }: ServiceDetailProps) {
  const detail = active ? SERVICE_DETAILS[active] : null;

  return (
    <section
      id="service-detail"
      className="scroll-mt-24 border-b border-hairline bg-surface"
    >
      <div className="mx-auto max-w-7xl px-5 py-16 sm:px-8 lg:py-24">
        {detail ? (
          <div className="grid gap-12 lg:grid-cols-[1.5fr_1fr]">
            <div>
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="label-caps">Service detail</p>
                  <h2
                    className={`mt-3 font-display text-3xl leading-tight font-medium tracking-[-0.02em] sm:text-4xl ${
                      detail.accent === "teal" ? "text-teal" : "text-amber"
                    }`}
                  >
                    {active}
                  </h2>
                </div>
                <button
                  type="button"
                  onClick={() => onSelect(null)}
                  className="clip-facet-sm flex items-center gap-2 border border-hairline bg-background px-4 py-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
                  aria-label="Close service detail"
                >
                  <X className="h-4 w-4" aria-hidden />
                  Close
                </button>
              </div>

              <p className="mt-6 max-w-2xl text-base leading-relaxed text-foreground">
                {detail.intro}
              </p>

              <ul className="mt-10 grid gap-4 sm:grid-cols-2">
                {detail.points.map((point) => (
                  <li
                    key={point}
                    className="flex items-start gap-3 text-sm text-muted-foreground"
                  >
                    <span
                      aria-hidden
                      className={`mt-1.5 h-1.5 w-1.5 shrink-0 ${
                        detail.accent === "teal" ? "bg-teal" : "bg-amber"
                      }`}
                      style={{ clipPath: "polygon(0 0, 100% 50%, 0 100%)" }}
                    />
                    {point}
                  </li>
                ))}
              </ul>

              <a
                href="#contact"
                onClick={() => onSelect(null)}
                className={`clip-facet-sm mt-10 inline-flex items-center gap-2 px-6 py-3 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90 ${
                  detail.accent === "teal" ? "bg-teal" : "bg-amber"
                }`}
              >
                Discuss this with us
                <ArrowRight className="h-4 w-4" aria-hidden />
              </a>
            </div>

            <div className="hidden lg:block">
              <div className="sticky top-28 border border-hairline bg-background p-6">
                <p className="label-caps">Other services</p>
                <div className="mt-4 flex flex-col gap-2">
                  {SERVICE_TITLES.map((title) => {
                    const d = SERVICE_DETAILS[title];
                    if (!d) return null;
                    const isActive = title === active;
                    return (
                      <button
                        key={title}
                        type="button"
                        onClick={() => onSelect(title)}
                        className={`text-left border px-4 py-3 text-sm transition-colors ${
                          isActive
                            ? "border-transparent bg-surface font-medium text-foreground"
                            : "border-hairline text-muted-foreground hover:text-foreground"
                        }`}
                        aria-pressed={isActive}
                      >
                        <span
                          className={`mr-3 inline-block h-1.5 w-1.5 ${
                            d.accent === "teal" ? "bg-teal" : "bg-amber"
                          }`}
                          style={{ clipPath: "polygon(0 0, 100% 50%, 0 100%)" }}
                          aria-hidden
                        />
                        {title}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center">
            <p className="label-caps">Service detail</p>
            <p className="mt-3 text-muted-foreground">
              Select a service above to see how we can help.
            </p>
          </div>
        )}
      </div>
    </section>
  );
}
