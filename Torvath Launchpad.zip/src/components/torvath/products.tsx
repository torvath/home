import { useState } from "react";
import { z } from "zod";

type Status = "live" | "dev" | "planned";

function StatusBadge({ status }: { status: Status }) {
  const map: Record<Status, { label: string; cls: string }> = {
    live: { label: "Live", cls: "border-teal text-teal" },
    dev: { label: "In development", cls: "border-amber text-amber" },
    planned: {
      label: "Planned",
      cls: "border-hairline text-muted-foreground",
    },
  };
  const s = map[status];
  return (
    <span
      className={`clip-facet-sm inline-block shrink-0 border px-3 py-1 font-display text-[0.65rem] tracking-[0.22em] uppercase ${s.cls}`}
    >
      {s.label}
    </span>
  );
}

const emailSchema = z
  .string()
  .trim()
  .min(1, { message: "Enter your email address." })
  .email({ message: "That does not look like a valid email." })
  .max(255, { message: "Email must be under 255 characters." });

function NotifyForm() {
  const [email, setEmail] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = emailSchema.safeParse(email);
    if (!parsed.success) {
      setError(parsed.error.issues[0]?.message ?? "Enter a valid email.");
      setDone(false);
      return;
    }
    setError(null);
    setDone(true);
    setEmail("");
  };

  return (
    <form onSubmit={onSubmit} noValidate className="mt-8 max-w-md">
      <label
        htmlFor="notify-email"
        className="label-caps block"
      >
        Get notified at launch
      </label>
      <div className="mt-3 flex flex-col gap-2 sm:flex-row">
        <input
          id="notify-email"
          type="email"
          name="email"
          autoComplete="email"
          placeholder="you@company.com"
          value={email}
          onChange={(e) => {
            setEmail(e.target.value);
            if (error) setError(null);
          }}
          aria-invalid={!!error}
          aria-describedby={error ? "notify-error" : done ? "notify-success" : undefined}
          className={`min-w-0 flex-1 border bg-background px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/70 ${
            error ? "border-destructive" : "border-hairline focus:border-teal"
          }`}
        />
        <button
          type="submit"
          className="clip-facet-sm shrink-0 bg-amber px-5 py-3 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
        >
          Notify me
        </button>
      </div>
      <div aria-live="polite" className="mt-2 min-h-5">
        {error && (
          <p id="notify-error" className="text-sm text-destructive">
            {error}
          </p>
        )}
        {done && !error && (
          <p id="notify-success" className="text-sm text-teal">
            You are on the list. We will email you when it launches.
          </p>
        )}
      </div>
    </form>
  );
}

export function Products() {
  return (
    <section id="products" className="scroll-mt-24 border-b border-hairline">
      <div className="mx-auto max-w-7xl px-5 py-24 sm:px-8 lg:py-32">
        <p className="label-caps">Products</p>
        <h2 className="mt-4 max-w-2xl font-display text-3xl leading-tight font-medium tracking-[-0.02em] sm:text-4xl">
          Applications we build and operate ourselves.
        </h2>

        <div className="mt-14 border-t border-hairline">
          <article className="border-b border-hairline py-10 lg:grid lg:grid-cols-[minmax(0,1fr)_auto] lg:gap-10">
            <div className="min-w-0">
              <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-4 sm:flex sm:items-center">
                <h3 className="min-w-0 font-display text-2xl font-medium tracking-[-0.02em] text-foreground sm:text-3xl">
                  Torvath Rentals
                </h3>
                <StatusBadge status="dev" />
              </div>
              <p className="mt-4 max-w-xl text-sm leading-relaxed text-muted-foreground sm:text-base">
                A rental platform that connects owners and renters, handling
                listings, availability, and bookings in one place.
              </p>
              <NotifyForm />
            </div>
            <div
              aria-hidden
              className="mt-10 hidden h-40 w-40 shrink-0 opacity-25 lg:block"
              style={{
                background: "var(--gradient-brand-diag)",
                clipPath:
                  "polygon(50% 0, 100% 30%, 82% 100%, 18% 100%, 0 30%)",
              }}
            />
          </article>

          <article className="border-b border-hairline py-10">
            <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-4 sm:flex sm:items-center">
              <h3 className="min-w-0 font-display text-2xl font-medium tracking-[-0.02em] text-muted-foreground sm:text-3xl">
                [Product name — to be announced]
              </h3>
              <StatusBadge status="planned" />
            </div>
            <p className="mt-4 max-w-xl text-sm leading-relaxed text-muted-foreground sm:text-base">
              [One-line description — placeholder. This row is reserved for the
              next product on our roadmap.]
            </p>
          </article>
        </div>
      </div>
    </section>
  );
}
