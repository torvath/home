const POINTS = [
  {
    n: "01",
    title: "Direct access.",
    body: "No account managers, no layers. You talk to the engineers building your system.",
  },
  {
    n: "02",
    title: "Fixed scope or embedded.",
    body: "Take a defined project at a fixed price, or embed with your team on a retainer.",
  },
  {
    n: "03",
    title: "We stay after launch.",
    body: "Software is not done when it ships. We maintain what we build.",
  },
];

export function Process() {
  return (
    <section
      id="process"
      className="relative scroll-mt-24 overflow-hidden border-b border-hairline bg-surface"
    >
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="grid-hairlines absolute inset-0 opacity-[0.12]" />
      </div>
      <div className="relative mx-auto max-w-7xl px-5 py-24 sm:px-8 lg:py-36">
        <p className="label-caps">How we work</p>
        <h2 className="mt-4 max-w-3xl font-display text-3xl leading-tight font-medium tracking-[-0.02em] sm:text-4xl lg:text-5xl">
          A small team, deliberately. That is the advantage.
        </h2>

        <ol className="mt-16 grid gap-12 lg:grid-cols-3 lg:gap-10">
          {POINTS.map((p, i) => (
            <li key={p.n} className="relative lg:pr-8">
              <div className="flex items-start gap-5">
                <span
                  className="font-display text-5xl leading-none font-light tracking-[-0.04em] text-transparent sm:text-6xl"
                  style={{
                    backgroundImage:
                      i === 2 ? "var(--gradient-brand)" : undefined,
                    backgroundClip: i === 2 ? "text" : undefined,
                    WebkitBackgroundClip: i === 2 ? "text" : undefined,
                    color: i === 2 ? "transparent" : i === 1 ? "var(--amber)" : "var(--teal)",
                  }}
                >
                  {p.n}
                </span>
                <span aria-hidden className="mt-6 h-px w-8 bg-hairline" />
              </div>
              <h3 className="mt-6 font-display text-xl font-medium tracking-[-0.01em] text-foreground">
                {p.title}
              </h3>
              <p className="mt-3 max-w-sm text-sm leading-relaxed text-muted-foreground">
                {p.body}
              </p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
