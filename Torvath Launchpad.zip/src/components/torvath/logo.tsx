import markAsset from "@/assets/torvath-mark.png.asset.json";
import lockupAsset from "@/assets/torvath-lockup.png.asset.json";

export function TorvathMark({ className = "h-8 w-8" }: { className?: string }) {
  return (
    <img
      src={markAsset.url}
      alt="Torvath faceted T mark"
      className={`${className} object-contain`}
      loading="eager"
      decoding="async"
    />
  );
}

export function TorvathLockup({ className = "" }: { className?: string }) {
  return (
    <img
      src={lockupAsset.url}
      alt="Torvath — Building Intelligent Solutions"
      className={`${className} object-contain`}
      loading="lazy"
      decoding="async"
    />
  );
}

export function TorvathLogo({ className = "" }: { className?: string }) {
  return (
    <span className={`flex min-w-0 items-center gap-2.5 ${className}`}>
      <TorvathMark className="h-8 w-8 shrink-0" />
      <span className="font-display text-[0.95rem] font-light tracking-[0.42em] text-foreground">
        TORVATH
      </span>
    </span>
  );
}
