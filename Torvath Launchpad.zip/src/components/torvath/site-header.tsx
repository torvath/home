import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import { TorvathLogo } from "./logo";

const NAV = [
  { label: "Services", href: "#services" },
  { label: "How we work", href: "#process" },
  { label: "Products", href: "#products" },
  { label: "Contact", href: "#contact" },
];

export function SiteHeader() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState<string>("");

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const sections = NAV.map((n) => document.querySelector(n.href)).filter(
      Boolean,
    ) as Element[];
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible) setActive(`#${visible.target.id}`);
      },
      { rootMargin: "-45% 0px -50% 0px", threshold: [0, 0.25, 0.5, 1] },
    );
    sections.forEach((s) => observer.observe(s));
    return () => observer.disconnect();
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-colors duration-300 ${
        scrolled
          ? "border-b border-hairline bg-background/80 backdrop-blur-md"
          : "border-b border-transparent"
      }`}
    >
      <div className="mx-auto grid max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-5 py-4 sm:px-8 lg:flex lg:justify-between">
        <a href="#top" className="min-w-0" aria-label="Torvath home">
          <TorvathLogo />
        </a>

        <nav className="hidden items-center gap-1 lg:flex" aria-label="Main">
          {NAV.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className={`clip-facet-sm border px-4 py-2 text-sm text-muted-foreground transition-colors hover:text-foreground ${
                active === item.href
                  ? "border-transparent text-foreground [background:linear-gradient(var(--surface),var(--surface))_padding-box,var(--gradient-brand)_border-box]"
                  : "border-transparent"
              }`}
            >
              {item.label}
            </a>
          ))}
          <a
            href="#contact"
            className="clip-facet-sm ml-3 bg-amber px-5 py-2 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
          >
            Start a project
          </a>
        </nav>

        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          aria-controls="mobile-nav"
          aria-label={open ? "Close menu" : "Open menu"}
          className="shrink-0 border border-hairline p-2 text-foreground lg:hidden"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {open && (
        <div
          id="mobile-nav"
          className="border-t border-hairline bg-background/95 backdrop-blur-md lg:hidden"
        >
          <nav className="flex flex-col px-5 py-2 sm:px-8" aria-label="Mobile">
            {NAV.map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className="border-b border-hairline py-4 text-sm text-muted-foreground transition-colors hover:text-foreground"
              >
                {item.label}
              </a>
            ))}
            <a
              href="#contact"
              onClick={() => setOpen(false)}
              className="clip-facet-sm my-4 bg-amber px-5 py-3 text-center text-sm font-medium text-primary-foreground"
            >
              Start a project
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}
