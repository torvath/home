import { useState } from "react";
import { z } from "zod";

const schema = z.object({
  name: z
    .string()
    .trim()
    .min(1, { message: "Please tell us your name." })
    .max(100, { message: "Name must be under 100 characters." }),
  email: z
    .string()
    .trim()
    .min(1, { message: "An email address is required." })
    .email({ message: "Enter a valid email address." })
    .max(255, { message: "Email must be under 255 characters." }),
  company: z
    .string()
    .trim()
    .max(120, { message: "Company must be under 120 characters." })
    .optional(),
  projectType: z.enum(["software", "consulting", "product", "unsure"], {
    message: "Select a project type.",
  }),
  message: z
    .string()
    .trim()
    .min(10, { message: "A few more words, please — at least 10 characters." })
    .max(2000, { message: "Message must be under 2000 characters." }),
});

type Errors = Partial<Record<keyof z.infer<typeof schema>, string>>;

const FIELD =
  "mt-2 w-full border bg-background px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/70";

export function Contact() {
  const [errors, setErrors] = useState<Errors>({});
  const [sent, setSent] = useState(false);

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const parsed = schema.safeParse({
      name: String(fd.get("name") ?? ""),
      email: String(fd.get("email") ?? ""),
      company: String(fd.get("company") ?? ""),
      projectType: String(fd.get("projectType") ?? ""),
      message: String(fd.get("message") ?? ""),
    });

    if (!parsed.success) {
      const next: Errors = {};
      for (const issue of parsed.error.issues) {
        const key = issue.path[0] as keyof Errors;
        if (key && !next[key]) next[key] = issue.message;
      }
      setErrors(next);
      setSent(false);
      return;
    }
    setErrors({});
    setSent(true);
    e.currentTarget.reset();
  };

  const border = (k: keyof Errors) =>
    errors[k] ? "border-destructive" : "border-hairline focus:border-teal";

  return (
    <section id="contact" className="scroll-mt-24 border-b border-hairline">
      <div className="mx-auto grid max-w-7xl gap-14 px-5 py-24 sm:px-8 lg:grid-cols-2 lg:gap-20 lg:py-32">
        <div>
          <p className="label-caps">Contact</p>
          <h2 className="mt-4 font-display text-3xl leading-tight font-medium tracking-[-0.02em] sm:text-4xl lg:text-5xl">
            Tell us what you&rsquo;re building.
          </h2>
          <p className="mt-6 max-w-md text-base leading-relaxed text-muted-foreground">
            A short first conversation is usually enough to tell whether we are
            the right team for the work. No pitch decks.
          </p>

          <div className="mt-10 h-px w-24 gradient-brand" />

          <dl className="mt-10 space-y-6">
            <div>
              <dt className="label-caps">Email</dt>
              <dd className="mt-2">
                <a
                  href="mailto:hello@torvath.com"
                  className="text-base text-foreground underline decoration-teal decoration-1 underline-offset-4 transition-colors hover:text-teal"
                >
                  hello@torvath.com
                </a>
              </dd>
            </div>
            <div>
              <dt className="label-caps">Location</dt>
              <dd className="mt-2 text-base text-foreground">
                Remote-first &middot; [City, Country — fill in]
              </dd>
            </div>
          </dl>
        </div>

        <form
          onSubmit={onSubmit}
          noValidate
          className="clip-facet border border-hairline bg-surface p-6 sm:p-9"
        >
          <div className="grid gap-6 sm:grid-cols-2">
            <div>
              <label htmlFor="name" className="label-caps">
                Name
              </label>
              <input
                id="name"
                name="name"
                autoComplete="name"
                aria-invalid={!!errors.name}
                aria-describedby={errors.name ? "name-error" : undefined}
                className={`${FIELD} ${border("name")}`}
              />
              {errors.name && (
                <p id="name-error" className="mt-2 text-sm text-destructive">
                  {errors.name}
                </p>
              )}
            </div>
            <div>
              <label htmlFor="email" className="label-caps">
                Email
              </label>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                aria-invalid={!!errors.email}
                aria-describedby={errors.email ? "email-error" : undefined}
                className={`${FIELD} ${border("email")}`}
              />
              {errors.email && (
                <p id="email-error" className="mt-2 text-sm text-destructive">
                  {errors.email}
                </p>
              )}
            </div>
          </div>

          <div className="mt-6 grid gap-6 sm:grid-cols-2">
            <div>
              <label htmlFor="company" className="label-caps">
                Company <span className="normal-case tracking-normal">(optional)</span>
              </label>
              <input
                id="company"
                name="company"
                autoComplete="organization"
                className={`${FIELD} ${border("company")}`}
              />
            </div>
            <div>
              <label htmlFor="projectType" className="label-caps">
                Project type
              </label>
              <select
                id="projectType"
                name="projectType"
                defaultValue=""
                aria-invalid={!!errors.projectType}
                aria-describedby={errors.projectType ? "type-error" : undefined}
                className={`${FIELD} ${border("projectType")}`}
              >
                <option value="" disabled>
                  Select one
                </option>
                <option value="software">Software development</option>
                <option value="consulting">Consulting</option>
                <option value="product">Product</option>
                <option value="unsure">Not sure yet</option>
              </select>
              {errors.projectType && (
                <p id="type-error" className="mt-2 text-sm text-destructive">
                  {errors.projectType}
                </p>
              )}
            </div>
          </div>

          <div className="mt-6">
            <label htmlFor="message" className="label-caps">
              Message
            </label>
            <textarea
              id="message"
              name="message"
              rows={5}
              placeholder="What are you building, and where is it now?"
              aria-invalid={!!errors.message}
              aria-describedby={errors.message ? "message-error" : undefined}
              className={`${FIELD} resize-y ${border("message")}`}
            />
            {errors.message && (
              <p id="message-error" className="mt-2 text-sm text-destructive">
                {errors.message}
              </p>
            )}
          </div>

          <button
            type="submit"
            className="clip-facet-sm mt-8 w-full bg-amber px-6 py-3 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90 sm:w-auto"
          >
            Send message
          </button>

          <div aria-live="polite" className="mt-4 min-h-6">
            {sent && (
              <p className="border-l-2 border-teal pl-3 text-sm text-teal">
                Thanks — your message is with us. We reply within one business
                day.
              </p>
            )}
          </div>
        </form>
      </div>
    </section>
  );
}
