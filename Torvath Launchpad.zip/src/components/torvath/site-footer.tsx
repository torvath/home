import { TorvathLockup } from "./logo";

const NAV = [
  { label: "Services", href: "#services" },
  { label: "How we work", href: "#process" },
  { label: "Products", href: "#products" },
  { label: "Contact", href: "#contact" },
];

export function SiteFooter() {
  return (
    <footer className="relative">
      <div aria-hidden className="h-px w-full gradient-brand" />
      <div className="mx-auto max-w-7xl px-5 py-14 sm:px-8">
        <div className="grid gap-10 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-start">
          <div className="min-w-0">
            <TorvathLockup className="h-40 w-auto sm:h-48" />

          </div>

          <nav aria-label="Footer" className="flex flex-wrap gap-x-8 gap-y-3">
            {NAV.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="text-sm text-muted-foreground transition-colors hover:text-foreground"
              >
                {item.label}
              </a>
            ))}
          </nav>
        </div>

        <div className="mt-12 border-t border-hairline pt-6">
          <p className="text-xs tracking-wide text-muted-foreground">
            &copy; {new Date().getFullYear()} Torvath. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
