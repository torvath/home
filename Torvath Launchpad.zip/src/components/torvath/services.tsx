const SERVICES = [
  {
    title: "Software development",
    body: "Web and mobile applications built end to end.",
    accent: "teal" as const,
  },
  {
    title: "Consulting",
    body: "Architecture reviews, technology selection, and getting a stalled project moving again.",
    accent: "teal" as const,
  },
  {
    title: "Products",
    body: "Our own applications, built and operated in-house.",
    accent: "amber" as const,
  },
  {
    title: "Managed services",
    body: "Ongoing maintenance, monitoring, and iteration after launch.",
    accent: "amber" as const,
  },
];

export const SERVICE_TITLES = SERVICES.map((s) => s.title);

export type ServiceTitle = (typeof SERVICE_TITLES)[number];

interface ServicesProps {
  active: ServiceTitle | null;
  onSelect: (title: ServiceTitle) => void;
}

export function Services({ active, onSelect }: ServicesProps) {
  return (
    <section id="services" className="scroll-mt-24 border-b border-hairline">
      <div className="mx-auto max-w-7xl px-5 py-24 sm:px-8 lg:py-32">
        <p className="label-caps">What we do</p>
        <h2 className="mt-4 max-w-2xl font-display text-3xl leading-tight font-medium tracking-[-0.02em] sm:text-4xl">
          Four ways we work with you.
        </h2>

        <div className="mt-14 grid gap-px bg-hairline sm:grid-cols-2 lg:grid-cols-4">
          {SERVICES.map((s) => {
            const isActive = active === s.title;
            return (
              <button
                key={s.title}
                type="button"
                onClick={() => {
                  onSelect(s.title);
                  const detail = document.getElementById("service-detail");
                  if (detail) {
                    detail.scrollIntoView({ behavior: "smooth", block: "start" });
                  }
                }}
                aria-expanded={isActive}
                aria-controls="service-detail"
                className={`group relative cursor-pointer bg-background p-7 text-left transition-colors sm:p-8 ${
                  s.accent === "teal" ? "hover:bg-surface" : "hover:bg-surface"
                } ${isActive ? "ring-1 ring-inset ring-current" : ""}`}
                style={{ color: isActive ? `var(--${s.accent})` : undefined }}
              >
                <span
                  aria-hidden
                  className={`block h-[2px] w-10 transition-all duration-300 group-hover:w-16 ${
                    s.accent === "teal" ? "bg-teal" : "bg-amber"
                  }`}
                  style={{
                    clipPath: "polygon(0 0, 100% 0, calc(100% - 6px) 100%, 0 100%)",
                  }}
                />
                <h3 className="mt-7 font-display text-lg font-medium tracking-[-0.01em] text-foreground">
                  {s.title}
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  {s.body}
                </p>
                <span className="mt-4 inline-flex items-center gap-1 text-sm font-medium transition-colors group-hover:text-foreground">
                  Learn more
                  <span aria-hidden className="transition-transform group-hover:translate-x-1">
                    →
                  </span>
                </span>
                <span
                  aria-hidden
                  className={`absolute inset-0 border transition-colors ${
                    s.accent === "teal"
                      ? "border-transparent group-hover:border-teal/50"
                      : "border-transparent group-hover:border-amber/50"
                  }`}
                />
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}
