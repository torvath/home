import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SiteHeader } from "@/components/torvath/site-header";
import { Hero } from "@/components/torvath/hero";
import { Services, type ServiceTitle } from "@/components/torvath/services";
import { ServiceDetail } from "@/components/torvath/service-detail";
import { Process } from "@/components/torvath/process";
import { Products } from "@/components/torvath/products";
import { Technology } from "@/components/torvath/technology";
import { Contact } from "@/components/torvath/contact";
import { SiteFooter } from "@/components/torvath/site-footer";

const TITLE = "Torvath — Building Intelligent Solutions";
const DESCRIPTION =
  "Torvath is a small engineering team that designs, builds, and maintains software — and ships products of its own. Work directly with the engineers.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const [activeService, setActiveService] = useState<ServiceTitle | null>(null);

  return (
    <div className="min-h-svh bg-background">
      <SiteHeader />
      <main>
        <Hero />
        <Services active={activeService} onSelect={setActiveService} />
        <ServiceDetail active={activeService} onSelect={setActiveService} />
        <Process />
        <Products />
        <Technology />
        <Contact />
      </main>
      <SiteFooter />
    </div>
  );
}
